package edu.kit.ipd.swt1;

import java.util.Properties;

public class EditMe {

	/**
	 * 
	 * @return "bar"
	 */
	public String getFoo() {
		//TODO implement me
		return null;
	}
	
	/**
	 * 
	 * @return your matriculation number
	 */
	public int getMatNum() {
		//TODO implement me
		return 0;
	}
}
