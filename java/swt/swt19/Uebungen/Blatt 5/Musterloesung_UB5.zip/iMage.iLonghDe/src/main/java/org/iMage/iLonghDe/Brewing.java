package org.iMage.iLonghDe;

public class Brewing extends AbstractState {

  private AbstractState next;

  public Brewing(CoffeeMaker machine) {
    super(machine);
  }

  @Override
  protected AbstractState next() {
    return this.next;
  }

  @Override
  protected void entry() {
    this.machine.display("BrewCoffee");
  }

  @Override
  protected void coffeeButtonPressed() {
    this.next = new Waiting(this.machine);
  }

  @Override
  protected void standbyButtonPressed() {
    this.next = new Standby(this.machine);
  }

  @Override
  protected void exit() {
    this.machine.display("Done");
  }
}
