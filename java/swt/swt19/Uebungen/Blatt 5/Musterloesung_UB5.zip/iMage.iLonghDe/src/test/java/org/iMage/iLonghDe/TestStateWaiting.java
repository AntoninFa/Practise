package org.iMage.iLonghDe;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class TestStateWaiting extends TestBase {

  @Override
  @Test
  public void testTransitionStandby() {
    super.testTransitionStandby();
    this.inState(Standby.class);
  }

  @Override
  @Test
  public void testTransitionCleaning() {
    super.testTransitionCleaning();
    this.inState(Cleaning.class);
  }

  @Override
  @Test
  public void testTransitionCoffee() {
    super.testTransitionCoffee();
    this.inState(Brewing.class);
  }

  @Override
  protected void reachState() {
    this.cleanupOut();
    this.coffeMaker.standbyButtonPressed();
    this.inState(Waiting.class);
    List<String> output = TestBase.readOutput();
    Assert.assertEquals(1, output.size());
    Assert.assertEquals("Waiting", output.get(0));
  }
}
