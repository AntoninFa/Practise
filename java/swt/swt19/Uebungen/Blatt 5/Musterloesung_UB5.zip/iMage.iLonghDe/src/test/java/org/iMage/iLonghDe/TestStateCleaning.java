package org.iMage.iLonghDe;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class TestStateCleaning extends TestBase {

  @Override
  @Test
  public void testTransitionCleaning() {
    super.testTransitionCleaning();
    this.inState(Waiting.class);
  }

  @Override
  @Test
  public void testTransitionStandby() {
    super.testTransitionStandby();
    this.inState(Standby.class);
  }

  @Override
  protected void reachState() {
    this.coffeMaker.standbyButtonPressed();
    this.cleanupOut();
    this.coffeMaker.cleaningButtonPressed();
    this.inState(Cleaning.class);
    List<String> output = TestBase.readOutput();
    Assert.assertEquals(1, output.size());
    Assert.assertEquals("Cleaning", output.get(0));
  }
}
