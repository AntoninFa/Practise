package org.iMage.iLonghDe;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.security.Permission;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.iMage.iLonghDe.base.IState;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Base class for all tests of {@link CoffeeMaker}.
 *
 * @author Dominik Fuchss
 *
 */
public abstract class TestBase {
  protected CoffeeMaker coffeMaker;

  protected static ByteArrayOutputStream out;

  /**
   * Setup CoffeeMaker
   */
  @Before
  public final void setup() {
    this.coffeMaker = new CoffeeMaker();
  }

  /**
   * Code to reach start state of tests. (and validate state)
   */
  protected abstract void reachState();

  /**
   * Default implementation to test transition based on {@link CoffeeMaker#standbyButtonPressed()}
   */
  @Test(expected = IllegalStateException.class)
  public void testTransitionStandby() {
    this.reachState();
    this.coffeMaker.standbyButtonPressed();
  }

  /**
   * Default implementation to test transition based on {@link CoffeeMaker#powerButtonPressed()}
   */
  @Test(expected = IllegalStateException.class)
  public void testTransitionPower() {
    this.reachState();
    this.coffeMaker.powerButtonPressed();
  }

  /**
   * Default implementation to test transition based on {@link CoffeeMaker#coffeeButtonPressed()}
   */
  @Test(expected = IllegalStateException.class)
  public void testTransitionCoffee() {
    this.reachState();
    this.coffeMaker.coffeeButtonPressed();
  }

  /**
   * Default implementation to test transition based on {@link CoffeeMaker#cleaningButtonPressed()}
   */
  @Test(expected = IllegalStateException.class)
  public void testTransitionCleaning() {
    this.reachState();
    this.coffeMaker.cleaningButtonPressed();
  }

  /**
   * Validate whether the current state is correct.
   *
   * @param state
   *          the expected state
   */
  protected final void inState(Class<? extends IState> state) {
    Assert.assertEquals(state, this.coffeMaker.getCurrentState().getClass());
  }

  /**
   * Read all recent output to stdout
   *
   * @return all recent lines
   */
  protected static List<String> readOutput() {
    String data = new String(TestBase.out.toByteArray());
    TestBase.out.reset();
    return Arrays.asList(data.split("\\n")).stream().map(s -> s.trim())
        .collect(Collectors.toList());
  }

  /**
   * Reset all output to stdout.
   */
  @After
  public final void cleanupOut() {
    TestBase.out.reset();
  }

  private static PrintStream realOut;

  /**
   * Mock stdout.
   */
  @BeforeClass
  public static void setupSysout() {
    TestBase.realOut = System.out;
    TestBase.out = new ByteArrayOutputStream();
    PrintStream ps = new PrintStream(TestBase.out);
    System.setOut(ps);
  }

  /**
   * Recover sysout.
   */
  @AfterClass
  public static void cleanupSysout() {
    System.out.close();
    System.setOut(TestBase.realOut);
    TestBase.realOut = null;
  }

  ///// Just prevent System.exit()

  /**
   * Prevent {@link System#exit(int)}.
   *
   * @throws Exception
   *           iff not allowed
   */
  @Before
  public void setUpSystemExit() throws Exception {
    System.setSecurityManager(new NoExitSecurityManager());
  }

  /**
   * Restore default behavior of {@link System#exit(int)}
   *
   * @throws Exception
   *           iff not allowed
   */
  @After
  public void tearDownSystemExit() throws Exception {
    System.setSecurityManager(null);
  }

  /**
   * This Exception will thrown on calls to {@link System#exit(int)}
   *
   * @author Dominik Fuchss
   *
   */
  protected static final class ExitException extends SecurityException {
    private static final long serialVersionUID = 8935932434520948849L;

    private ExitException(int status) {
      super("System.exit(" + status + ")");
    }
  }

  /**
   * The Mocked SecurityManager
   *
   * @author Dominik Fuchss
   *
   */
  protected static final class NoExitSecurityManager extends SecurityManager {
    @Override
    public void checkPermission(Permission perm) {
      // allow anything.
    }

    @Override
    public void checkPermission(Permission perm, Object context) {
      // allow anything.
    }

    @Override
    public void checkExit(int status) {
      super.checkExit(status);
      throw new ExitException(status);
    }
  }

}
