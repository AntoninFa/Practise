package org.iMage.iLonghDe;

public class Waiting extends AbstractState {

  private AbstractState next;

  public Waiting(CoffeeMaker machine) {
    super(machine);
  }

  @Override
  protected AbstractState next() {
    return this.next;
  }

  @Override
  protected void entry() {
    this.machine.display("Waiting");
  }

  @Override
  protected void coffeeButtonPressed() {
    this.next = new Brewing(this.machine);
  }

  @Override
  protected void cleaningButtonPressed() {
    this.next = new Cleaning(this.machine);
  }

  @Override
  protected void standbyButtonPressed() {
    this.next = new Standby(this.machine);
  }
}
