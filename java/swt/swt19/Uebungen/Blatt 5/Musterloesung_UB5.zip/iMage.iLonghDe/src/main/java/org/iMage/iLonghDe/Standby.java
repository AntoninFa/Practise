package org.iMage.iLonghDe;

public class Standby extends AbstractState {

  private AbstractState next;

  @Override
  protected AbstractState next() {
    return this.next;
  }

  @Override
  protected void entry() {
    this.machine.display("");
  }

  @Override
  protected void powerButtonPressed() {
    System.exit(1);
  }

  @Override
  protected void standbyButtonPressed() {
    this.next = new Waiting(this.machine);
  }

  public Standby(CoffeeMaker machine) {
    super(machine);
  }

}
