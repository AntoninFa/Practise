package org.iMage.iLonghDe;

public class Cleaning extends AbstractState {

  private AbstractState next;

  public Cleaning(CoffeeMaker machine) {
    super(machine);
  }

  @Override
  protected AbstractState next() {
    return this.next;
  }

  @Override
  protected void entry() {
    this.machine.display("Cleaning");
  }

  @Override
  protected void cleaningButtonPressed() {
    this.next = new Waiting(this.machine);
  }

  @Override
  protected void standbyButtonPressed() {
    this.next = new Standby(this.machine);
  }

}
