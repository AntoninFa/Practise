package org.iMage.iLonghDe;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class TestStateStandby extends TestBase {
  @Override
  @Test
  public void testTransitionStandby() {
    super.testTransitionStandby();
    this.inState(Waiting.class);
  }

  @Override
  @Test(expected = ExitException.class)
  public void testTransitionPower() {
    super.testTransitionPower();
  }

  @Override
  protected void reachState() {
    this.inState(Standby.class);
    List<String> output = TestBase.readOutput();
    Assert.assertEquals(1, output.size());
    Assert.assertEquals("", output.get(0));
  }
}
