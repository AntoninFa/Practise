package org.iMage.iLonghDe;

import org.iMage.iLonghDe.base.IState;
import org.iMage.iLonghDe.base.IStateMachine;

public class CoffeeMaker implements IStateMachine {

  AbstractState current;

  public CoffeeMaker() {
    this.current = new Standby(this);
  }

  @Override
  public void powerButtonPressed() {
    this.current.powerButtonPressed();
    this.current.transition();
  }

  @Override
  public void standbyButtonPressed() {
    this.current.standbyButtonPressed();
    this.current.transition();
  }

  @Override
  public void coffeeButtonPressed() {
    this.current.coffeeButtonPressed();
    this.current.transition();
  }

  @Override
  public void cleaningButtonPressed() {
    this.current.cleaningButtonPressed();
    this.current.transition();
  }

  @Override
  public IState getCurrentState() {
    return this.current;
  }
}
