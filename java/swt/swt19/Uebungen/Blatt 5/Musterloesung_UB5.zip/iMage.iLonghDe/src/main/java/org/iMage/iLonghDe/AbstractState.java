package org.iMage.iLonghDe;

import org.iMage.iLonghDe.base.IState;

public abstract class AbstractState implements IState {

  protected CoffeeMaker machine;

  public AbstractState(CoffeeMaker machine) {
    this.machine = machine;
  }

  protected void powerButtonPressed() {
    throw new IllegalStateException();
  }

  protected void standbyButtonPressed() {
    throw new IllegalStateException();
  }

  protected void coffeeButtonPressed() {
    throw new IllegalStateException();
  }

  protected void cleaningButtonPressed() {
    throw new IllegalStateException();
  }

  /**
   * The state's entry actions.
   */
  protected void entry() {
  }

  /**
   * The state's transition actions.
   */
  protected final void transition() {
    AbstractState next = next();
    this.exit();
    next.entry();
    machine.current = next;
  }

  protected abstract AbstractState next();

  /**
   * The state's exit actions.
   */
  protected void exit() {
  }
}
