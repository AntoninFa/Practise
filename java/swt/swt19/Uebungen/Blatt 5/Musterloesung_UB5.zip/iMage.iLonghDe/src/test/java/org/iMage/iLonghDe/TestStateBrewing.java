package org.iMage.iLonghDe;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class TestStateBrewing extends TestBase {

  @Override
  @Test
  public void testTransitionStandby() {
    super.testTransitionStandby();
    this.inState(Standby.class);
    List<String> output = TestBase.readOutput();
    Assert.assertEquals(2, output.size());
    Assert.assertEquals("Done", output.get(0));
  }

  @Override
  @Test
  public void testTransitionCoffee() {
    super.testTransitionCoffee();
    this.inState(Waiting.class);
    List<String> output = TestBase.readOutput();
    Assert.assertEquals(2, output.size());
    Assert.assertEquals("Done", output.get(0));

  }

  @Override
  protected void reachState() {
    this.coffeMaker.standbyButtonPressed();
    this.cleanupOut();
    this.coffeMaker.coffeeButtonPressed();

    this.inState(Brewing.class);
    List<String> output = TestBase.readOutput();
    Assert.assertEquals(1, output.size());
    Assert.assertEquals("BrewCoffee", output.get(0));
  }
}
