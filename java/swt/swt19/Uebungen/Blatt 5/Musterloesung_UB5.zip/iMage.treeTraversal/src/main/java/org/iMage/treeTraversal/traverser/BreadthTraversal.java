package org.iMage.treeTraversal.traverser;

import java.util.LinkedList;
import java.util.Queue;

import org.iMage.treeTraversal.model.Leaf;
import org.iMage.treeTraversal.model.Node;
import org.iMage.treeTraversal.model.Tree;

/**
 * Implements a BFS.
 */
public final class BreadthTraversal extends Traversal {

  private final Queue<Tree> toBeVisited = new LinkedList<>();

  /**
   * Create by start item.
   *
   * @param startItem
   *          the start item
   */
  public BreadthTraversal(Tree startItem) {
    super(startItem);
  }

  @Override
  public boolean hasNext() {
    return !this.toBeVisited.isEmpty()
        || (!this.getCurrentItem().hasParent() && !this.alreadyVisited(this.getCurrentItem()));
  }

  @Override
  public Tree visitLeaf(Leaf leaf) {
    if (!this.alreadyVisited(leaf)) {
      return leaf;
    } else if (!this.toBeVisited.isEmpty()) {
      return this.toBeVisited.remove().accept(this);
    }

    return null;
  }

  @Override
  public Tree visitNode(Node node) {
    if (!this.alreadyVisited(node)) {
      this.toBeVisited.addAll(node.getChildren());
      return node;
    } else {
      return this.toBeVisited.remove().accept(this);
    }
  }

}
