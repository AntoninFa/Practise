package org.iMage.treeTraversal;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.iMage.treeTraversal.runners.Runner;
import org.iMage.treeTraversal.traverser.Traversal;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

/**
 * The base class for all test of {@link Traversal} and {@link Runner}.
 *
 * @author Dominik Fuchss
 *
 */
public class TestBase {
  protected File baseDir;

  /**
   * Set start directory.
   */
  @Before
  public final void setupDir() {
    this.baseDir = new File("src/test/resources/test-dir");
  }

  protected static ByteArrayOutputStream out;

  protected static PrintStream realOut;

  /**
   * Read all recent output to stdout
   *
   * @return all recent lines
   */
  protected static List<String> readOutput() {
    String data = new String(TestBase.out.toByteArray());
    TestBase.out.reset();
    return Arrays.asList(data.split("\\n")).stream().map(s -> s.trim())
        .collect(Collectors.toList());
  }

  /**
   * Reset all output to stdout.
   */
  @After
  public final void cleanupOut() {
    TestBase.out.reset();
  }

  /**
   * Mock stdout.
   */
  @BeforeClass
  public static void setupSysout() {
    TestBase.realOut = System.out;
    TestBase.out = new ByteArrayOutputStream();
    PrintStream ps = new PrintStream(TestBase.out);
    System.setOut(ps);
  }

  /**
   * Recover sysout.
   */
  @AfterClass
  public static void cleanupSysout() {
    System.out.close();
    System.setOut(TestBase.realOut);
    TestBase.realOut = null;
  }

}
