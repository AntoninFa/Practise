package org.iMage.treeTraversal.runners;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.iMage.treeTraversal.model.Leaf;
import org.iMage.treeTraversal.model.Node;
import org.iMage.treeTraversal.model.Tree;
import org.iMage.treeTraversal.traverser.Traversal;

/**
 * A runner extracts files by using {@link Tree Trees}.
 */
public abstract class Runner {
  /**
   * Execute the runner.
   *
   * @param startFolder
   *          the start folder
   * @param traversalClass
   *          the traversal class
   */
  public final void run(File startFolder, Class<? extends Traversal> traversalClass) {
    Tree tree = this.buildFolderStructure(startFolder);
    List<File> files = this.getFiles(tree, traversalClass);
    List<File> selectedFiles = this.selectFiles(files);
    this.printResults(selectedFiles);
  }

  /**
   * Builds a {@link Tree} starting with a start folder.
   *
   * @param startFolder
   *          the start folder
   * @return the {@link Tree}
   */
  private Tree buildFolderStructure(File startFolder) {
    if (!startFolder.isDirectory()) {
      throw new IllegalArgumentException("start folder needs to be a folder");
    }
    return this.buildFolderStructure(startFolder, null);
  }

  private Tree buildFolderStructure(File current, Tree parent) {
    if (current.isFile()) {
      return new Leaf(current, parent);
    }

    Node folder = new Node(current, parent);

    List<Tree> children = new ArrayList<>();
    for (File child : current.listFiles()) {
      children.add(this.buildFolderStructure(child, folder));
    }
    children.forEach(folder::addChild);

    return folder;

  }

  /**
   * Get a list of all files using the iterator defined by {@link Traversal}.
   *
   * @param tree
   *          the tree
   * @param traversalClass
   *          the traversal
   * @return the list of traversed files (in order of traversal)
   */
  private List<File> getFiles(Tree tree, Class<? extends Traversal> traversalClass) {
    List<File> res = new ArrayList<>();
    tree.getIterator(traversalClass).forEachRemaining(t -> res.add(t.getFile()));
    return res;
  }

  /**
   * Filter files according to strategy.
   *
   * @param files
   *          the files
   * @return the filtered list of files
   */
  protected abstract List<File> selectFiles(List<File> files);

  /**
   * Print a list of files to stdout.
   * 
   * @param selectedFiles
   *          the list of files
   */
  private void printResults(List<File> selectedFiles) {
    selectedFiles.forEach(System.out::println);
  }

}
