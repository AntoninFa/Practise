package org.iMage.treeTraversal;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.iMage.treeTraversal.runners.JPGRunner;
import org.iMage.treeTraversal.runners.PNGRunner;
import org.iMage.treeTraversal.runners.Runner;
import org.iMage.treeTraversal.traverser.BreadthTraversal;
import org.iMage.treeTraversal.traverser.DepthTraversal;
import org.iMage.treeTraversal.traverser.Traversal;
import org.junit.Assert;
import org.junit.Test;

/**
 * Test class for all {@link Runner}.
 *
 * @author Dominik Fuchss
 *
 */
public class TestRunners extends TestBase {
  /**
   * Test {@link DepthTraversal} with {@link PNGRunner} and {@link JPGRunner}.
   *
   * @throws IOException
   *           iff reading failed
   */
  @Test
  public void testDepth() throws IOException {
    this.testRunner(new PNGRunner(), DepthTraversal.class,
        List.of("src/test/resources/test-dir/a.png", "src/test/resources/test-dir/b.png",
            "src/test/resources/test-dir/subfolder-A/b.png",
            "src/test/resources/test-dir/subfolder-A/f.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/a.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/d.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/a.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/c.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/a.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/b.png",
            "src/test/resources/test-dir/subfolder-B/a.png",
            "src/test/resources/test-dir/subfolder-B/e.png"));
    this.testRunner(new JPGRunner(), DepthTraversal.class,
        List.of("src/test/resources/test-dir/a.jpg", "src/test/resources/test-dir/b.jpg",
            "src/test/resources/test-dir/subfolder-A/a.jpg",
            "src/test/resources/test-dir/subfolder-A/g.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/a.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/b.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/a.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/b.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/a.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/b.jpg",
            "src/test/resources/test-dir/subfolder-B/a.jpg",
            "src/test/resources/test-dir/subfolder-B/b.jpg"));
  }

  /**
   * Test {@link BreadthTraversal} with {@link PNGRunner} and {@link JPGRunner}.
   *
   * @throws IOException
   *           iff reading failed
   */
  @Test
  public void testBreadth() throws IOException {
    this.testRunner(new PNGRunner(), BreadthTraversal.class,
        List.of("src/test/resources/test-dir/a.png", "src/test/resources/test-dir/b.png",
            "src/test/resources/test-dir/subfolder-A/b.png",
            "src/test/resources/test-dir/subfolder-A/f.png",
            "src/test/resources/test-dir/subfolder-B/a.png",
            "src/test/resources/test-dir/subfolder-B/e.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/a.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/d.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/a.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/b.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/a.png",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/c.png"));
    this.testRunner(new JPGRunner(), BreadthTraversal.class,
        List.of("src/test/resources/test-dir/a.jpg", "src/test/resources/test-dir/b.jpg",
            "src/test/resources/test-dir/subfolder-A/a.jpg",
            "src/test/resources/test-dir/subfolder-A/g.jpg",
            "src/test/resources/test-dir/subfolder-B/a.jpg",
            "src/test/resources/test-dir/subfolder-B/b.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/a.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/b.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/a.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A2/b.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/a.jpg",
            "src/test/resources/test-dir/subfolder-A/subfolder-A1/subfolder-A11/b.jpg"));
  }

  /**
   * Compare runner results.
   * 
   * @param runner
   *          the runner
   * @param traversal
   *          the traversal
   * @param files
   *          the expected files
   * @throws IOException
   *           iff reading is not possible
   */
  private void testRunner(Runner runner, Class<? extends Traversal> traversal, List<String> files)
      throws IOException {
    runner.run(this.baseDir, traversal);
    List<String> actualFiles = TestBase.readOutput();

    //    for (String file : actualFiles) {
    //      TestBase.REAL_OUT.println("\"" + file.replace("\\", "/") + "\",");
    //    }

    Assert.assertEquals(files.size(), actualFiles.size());

    int i = 0;
    for (String file : actualFiles) {
      File actual = new File(file);
      File expected = new File(files.get(i));
      if (!actual.getCanonicalPath().equals(expected.getCanonicalPath())) {
        Assert.fail("File " + file + " has been found but expected file was: " + files.get(i - 1));
      }
      i++;
    }

  }

}
