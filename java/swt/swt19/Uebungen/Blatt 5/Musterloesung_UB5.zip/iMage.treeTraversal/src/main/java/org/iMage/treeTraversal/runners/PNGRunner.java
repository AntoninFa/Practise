package org.iMage.treeTraversal.runners;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * A {@link Runner} which selects PNG-Files.
 */
public final class PNGRunner extends Runner {

  @Override
  protected List<File> selectFiles(List<File> files) {
    List<File> res = new ArrayList<>(files);
    res.removeIf(f -> !f.isFile() || !f.getName().toLowerCase().endsWith(".png"));
    return res;
  }

}
