package org.iMage.treeTraversal.traverser;

import java.util.Objects;

import org.iMage.treeTraversal.model.Leaf;
import org.iMage.treeTraversal.model.Node;
import org.iMage.treeTraversal.model.Tree;

/**
 * Implements a DFS.
 */
public final class DepthTraversal extends Traversal {
  /**
   * Create by start item.
   *
   * @param startItem
   *          the start item
   */
  public DepthTraversal(Tree startItem) {
    super(startItem);
  }

  @Override
  public boolean hasNext() {
    return !Objects.isNull(this.getCurrentItem().accept(this));
  }

  @Override
  public Tree visitLeaf(Leaf leaf) {
    if (this.alreadyVisited(leaf)) {
      if (leaf.hasParent()) {
        return leaf.getParent().accept(this);
      }
    } else {
      return leaf;
    }
    return null;
  }

  @Override
  public Tree visitNode(Node node) {
    if (this.alreadyVisited(node)) {
      for (Tree child : node.getChildren()) {
        if (!this.alreadyVisited(child)) {
          return child.accept(this);
        }
      }
      if (node.hasParent()) {
        return node.getParent().accept(this);
      }
    } else {
      return node;
    }
    return null;
  }

}
