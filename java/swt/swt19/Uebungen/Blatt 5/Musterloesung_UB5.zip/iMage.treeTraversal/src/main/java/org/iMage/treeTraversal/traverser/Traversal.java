package org.iMage.treeTraversal.traverser;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.iMage.treeTraversal.model.Leaf;
import org.iMage.treeTraversal.model.Node;
import org.iMage.treeTraversal.model.Tree;

/**
 * Defines an iterator over the elements of a {@link Tree}.
 */
public abstract class Traversal implements Iterator<Tree> {
  private Tree currentItem;
  private final Set<Tree> alreadyVisited = new HashSet<>();

  /**
   * Create by starting item.
   *
   * @param startItem
   *          the start item
   *
   */
  protected Traversal(Tree startItem) {
    this.currentItem = startItem;
  }

  /**
   * Visit a {@link Leaf}.
   *
   * @param leaf
   *          the leaf.
   * @return the resulting {@link Tree} of this invocation
   */
  public abstract Tree visitLeaf(Leaf leaf);

  /**
   * Visit a {@link Node}.
   *
   * @param node
   *          the node.
   * @return the resulting {@link Tree} of this invocation
   */
  public abstract Tree visitNode(Node node);

  @Override
  public final Tree next() {
    this.currentItem = this.currentItem.accept(this);
    this.alreadyVisited.add(this.currentItem);
    return this.currentItem;
  }

  /**
   * Indicates whether the tree is already visited.
   *
   * @param tree
   *          the tree
   * @return indicator
   */
  protected final boolean alreadyVisited(Tree tree) {
    return this.alreadyVisited.contains(tree);
  }

  /**
   * Get the current item.
   *
   * @return the current item
   */
  protected final Tree getCurrentItem() {
    return this.currentItem;
  }
}
