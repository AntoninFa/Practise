package org.iMage.treeTraversal.traverser;

import org.iMage.treeTraversal.model.Tree;

/**
 * Factory class for {@link Traversal}.
 */
public final class TraversalFactory {
  private TraversalFactory() {
    throw new IllegalAccessError();
  }

  /**
   * Create a traversal by its class and the tree.
   *
   * @param traversal
   *          the class
   * @param initialItem
   *          the initial tree item
   * @return the traversal
   */
  public static Traversal createTraversal(Class<? extends Traversal> traversal, Tree initialItem) {
    switch (Traversals.fromClass(traversal)) {
    case BREADTH:
      return new BreadthTraversal(initialItem);
    case DEPTH:
    case UNKNOWN:
    default:
      return new DepthTraversal(initialItem);
    }
  }

  /**
   * The different types of traversals.
   */
  public enum Traversals {
    /**
     * BFS
     */
    BREADTH(BreadthTraversal.class),
    /**
     * DFS
     */
    DEPTH(DepthTraversal.class),

    /**
     * Unknown (Fallback)
     */
    UNKNOWN(null);

    private final Class<? extends Traversal> traversal;

    /**
     * Create type by class of {@link Traversal}.
     *
     * @param targetClass
     *          the class
     */
    Traversals(Class<? extends Traversal> targetClass) {
      this.traversal = targetClass;
    }

    /**
     * Defines the class {@link Traversal}.
     * 
     * @return the class of {@link Traversal}
     */
    public Class<? extends Traversal> getTraversal() {
      return this.traversal;
    }

    /**
     * Find {@link Traversals} according to class of {@link Traversal}.
     *
     * @param cls
     *          the class
     * @return the {@link Traversals}
     */
    public static Traversals fromClass(Class<? extends Traversal> cls) {
      for (Traversals value : Traversals.values()) {
        if (value.traversal.equals(cls)) {
          return value;
        }
      }
      return UNKNOWN;
    }
  }
}
