package org.iMage.HDrize.matrix;

import org.iMage.HDrize.base.matrix.IMatrixCalculator;

public class MatrixCalculator implements IMatrixCalculator<Matrix> {

  @Override
  public Matrix inverse(Matrix mtx) {
    throw new UnsupportedOperationException("TODO Implement me!");
  }

  @Override
  public Matrix multiply(Matrix a, Matrix b) {
    throw new UnsupportedOperationException("TODO Implement me!");
  }

  @Override
  public Matrix transpose(Matrix mtx) {
    throw new UnsupportedOperationException("TODO Implement me!");
  }

}
